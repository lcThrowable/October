var sameFieldLcinusred={
	"lcinsuredname"	:"appntname",
	"lcinsurednativeplace"	:"nativeplace",//国籍
	"lcinsuredsex"	:"appntsex",//性别
	"lcinsuredroccupationcode"	:"occupationcode",//职业代码
	"lcinsuredidtype"	:"idtype",//证件类型
	"lcinsuredidno"	:"idno",//证件号码
	"lcinsuredcompany"	:"company",//工作单位及名称
	"lcinsuredbirthday"	:"appntbirthday",//出生日期
	"insureidenddate"	:"appntenddate",//证件有效止期
	"rgtaddress"	:"rgtaddress",//个人年收入(万元)
	"occupationtype"	:"occupationtype",// 行业代码
	"lcinsuredbirthcounty":"birthcounty",
//	"lcinsuredbirthcounty"	:"appntenddate",// 被保人出生地国家
	"industrytype"	:"industrytype",// 行业类别
		"jade":"jade"

};

var sameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"postprovince"	:"postprovince",//通讯地址省
		"postdistrict"	:"postdistrict",//通讯地址区
		"postcity"	:"postcity",//通讯地址市
		"postaladdress"	:"postaladdress",//通讯地址
		"mobile"	:"mobile",//移动电话
		"homezipcode"	:"homezipcode",//
		"homeprovince"	:"homeprovince",//
		"homephone"	:"homephone",//家庭电话
		"homedistrict"	:"homedistrict",//居住地址区
		"homecity"	:"homecity",//居住地址市
		"homeaddress"	:"homeaddress",//居住地址
		"email"	:"email",
		"postalflags"	:"postalflags",
		"countrycodetel_tel":"countrycodetel_tel",
		"areacodetel":"areacodetel",
		"countrycodetel_mob":"countrycodetel_mob"
	};

var onlysameFieldLcinusredAddress={
		"zipcode"	:"zipcode",//联系地址邮政编码
		"postprovince"	:"postprovince",//通讯地址省
		"postdistrict"	:"postdistrict",//通讯地址区
		"postcity"	:"postcity",//通讯地址市
		"postaladdress"	:"postaladdress"//通讯地址
		 
	};


/**
 * 投保人 同被保人
 */
afterVueSelect.lcinsuredrelationtoappnt = function(form_element) {

	var topvue = getTopvueObj(this);
 
	var form =$(this.$el)
	.parentsUntil("form").parent("form");
	if (this.formdata.relationtoappnt=="8") {

		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
		
				bindSameElement.call(topvue, topvue.formdata.lcappnt, sameFieldLcinusred[targetName],
						topvue.formdata.lcinsured,targetName,targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				bindSameElement.call(topvue, topvue.formdata.lcappntaddress, sameFieldLcinusredAddress[targetName],
						topvue.formdata.lcinsuredaddress,targetName,targetElement);
			}

		}
		
		
		topvue.$nextTick(function () { 
			try {
				form.data('bootstrapValidator').resetForm();
			} catch (e) {
			}
		});
		
		
		$("#lcinsuredpostalflag").hide();
//		topvue.$set(topvue.form_elementsBYID.lcinsured,"","04");
	} else {
		
		
		
		for ( var key in topvue.form_elements.lcinsured) {
			
			var targetName= topvue.form_elements.lcinsured[key].name;
			var targetElement= topvue.form_elements.lcinsured[key];
			if (sameFieldLcinusred[topvue.form_elements.lcinsured[key].name]!=undefined) {
		
				unbindSameElement.call(topvue, sameFieldLcinusred[targetName],
						targetElement);
			}
			
			if (sameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
				
				unbindSameElement.call(topvue, sameFieldLcinusredAddress[targetName],
						targetElement);
			}

		}
		$("#lcinsuredpostalflag").show();
//		topvue.$set(topvue.form_elementsBYID.lcinsured,"lcinsuredpostalflag","01");
	}

};




/**
 * 投保人 同被保人
 */
 
afterVueSelect.lcinsuredtwoflag = function(form_element) {
	
	var formdata = this.formdata;
	if(   formdata['lcinsured']
		&&formdata['lcinsured'].lcinsuredtwoflag
		&&formdata['lcinsured'].lcinsuredtwoflag.length>=1
		&&formdata['lcinsured'].lcinsuredtwoflag[0]=='lcinsuredtwoflag'){
		
		return true;
	}else{
 
		return false;
	}
	
};

/**
 * 投保人地址同被保人地址
 */
afterVueSelect.lcinsuredpostalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");

	if (topvue.formdata.lcinsured.relationtoappnt!="8") {
		
		
		if (obj.is("[type='checkbox']:checked")) {
			
			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredaddress,targetName,targetElement);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsured[key].name;
				var targetElement= topvue.form_elements.lcinsured[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsured[key].name]!=undefined) {
					unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement);
				}
			}
		}
		
		
	}
	

};

/**
 * 投保人地址 同被保人2地址
 */
afterVueSelect.lcinsuredtwopostalflag = function(form_element) {

	var topvue = getTopvueObj(this);
	var obj = $("#"+form_element.id);
	
	
	if(topvue.formdata.newContApply.investment=='M'
		&&topvue.formdata['lcinsuredmulti']){
		
		var eleName = this.namepref 
			+this.form_element.groupid+''+this.elementindex+'.'+ this.form_element.name;
		
		obj=$("input[name='"+eleName+"']");
	
		if (obj.is("[type='checkbox']:checked")) {
			
			for ( var key in topvue.form_elements.lcinsuredmulti) {
				
				var targetName= topvue.form_elements.lcinsuredmulti[key].name;
				var targetElement= topvue.form_elements.lcinsuredmulti[key];
				var index = getIndex(eleName);
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				if(targetName.indexOf("zip")>0){
					var tttt="";
				}
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredmulti[key].name]!=undefined) {
					bindSameElementByJqobj.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredmulti[index].lcaddress,targetName,targetElement,targetObj);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.lcinsuredmulti) {
 
				var targetName= topvue.form_elements.lcinsuredmulti[key].name;
				var targetElement= topvue.form_elements.lcinsuredmulti[key];
				var index = getIndex(eleName);
				var targetObj = $("input[name='"+eleName.replace(this.form_element.name,targetName)+"']");
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredmulti[key].name]!=undefined) {
					unbindSameElementByJqobj.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement,targetObj);
				}
			}
		}
		
	}else{
		if (obj.is("[type='checkbox']:checked")) {
			
			for ( var key in topvue.form_elements.lcinsured) {
				
				var targetName= topvue.form_elements.lcinsuredtwo[key].name;
				var targetElement= topvue.form_elements.lcinsuredtwo[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredtwo[key].name]!=undefined) {
					bindSameElement.call(topvue, topvue.formdata.lcappntaddress, onlysameFieldLcinusredAddress[targetName],
							topvue.formdata.lcinsuredtwoaddress,targetName,targetElement);
				}
			}
		
		} else {
			for ( var key in topvue.form_elements.lcinsured) {
				var targetName= topvue.form_elements.lcinsuredtwo[key].name;
				var targetElement= topvue.form_elements.lcinsuredtwo[key];
				if (onlysameFieldLcinusredAddress[topvue.form_elements.lcinsuredtwo[key].name]!=undefined) {
					unbindSameElement.call(topvue, onlysameFieldLcinusredAddress[targetName],
							targetElement);
				}
			}
		}
		
	}

	

};

//dbs_city  dbs_province dbs_area 被保人通讯地址省
commonCombobox_option.commonCombobox_insuredpostprovince ={

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
}; 
//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredpostcity  =  {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredpostprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人通讯地址
commonCombobox_option.commonCombobox_insuredpostdistrict = {

	url :  path + '/newCont/codeselect/allcounty/#lcinsuredpostcity.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};

//dbs_city  dbs_province dbs_area 被保人居住地址(省)
commonCombobox_option.commonCombobox_insuredhomeprovince = {

	url :  path + '/newCont/codeselect/allprovinceid/province.do',
	valueField : "provinceid",
	// 显示在输入框的
	inputText : "provincename",
	textShow : [ "provincename" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(市)
commonCombobox_option.commonCombobox_insuredhomecity = {
	url :  path + '/newCont/codeselect/allcity/#lcinsuredhomeprovince.do',
	valueField : "cityid",
	// 显示在输入框的
	inputText : "cityname",
	textShow : [ "cityname" ]
};
//dbs_city  dbs_province dbs_area 被保人居住地址(区)
commonCombobox_option.commonCombobox_insuredhomedistrict = {
	url :  path + '/newCont/codeselect/allcounty/#lcinsuredhomecity.do',
	valueField : "countyid",
	// 显示在输入框的
	inputText : "countyname",
	textShow : [ "countyname" ]
};
//var showdilog="";
//beforesubmitvueform.lcinsured_tabinfoform = function() {
//	showdilog= layer.load(0, {
//			  shade: [0.1,'#fff'] //0.1透明度的白色背景
//		   });
//	return true;
//}

//根据身份证号，同步出生日期
afterVueSelect.lcinsuredidno = function(form_element) {
	var topvue = getTopvueObj(this);
	var obj = $("[name='" + form_element.groupid + this.elementindex + "."
			+ form_element.name + "']");
	/*var form = $(this.$el).parentsUntil("form").parent("form");*/
	if($("#lcinsuredidtype").val() != "I" && $("#lcinsuredidtype").val() != "J"){
		return;
	}
	if($("#lcinsuredidtype").val() == "I"||$("#lcinsuredidtype").val() == "J"){
		if (obj.is("[id='lcinsuredidno']")){
//			topvue.$set(topvue.formdata.lcinsured,"insureidenddate","2099-01-01"); 
			var idno = $("#lcinsuredidno").val();
			var birthday = idno.substring(6,14);
			var year = birthday.substring(0,4);
			var mon = birthday.substring(4,6);
			var day = birthday.substring(6);
			var formatBirth = year + "-" + mon + "-" + day;
			topvue.$set(topvue.formdata.lcinsured,"lcinsuredbirthday",formatBirth);
			
		}
	/*	//重置出生日期的校验
		if($("#lcinsuredidno").val().length == 18){
			form.data('bootstrapValidator').resetField($('#lcinsuredbirthday'));
//			$.fn.bootstrapValidator.validators.lcinsured_idno;
		}*/
	}
	
}
$.fn.bootstrapValidator.validators.lcinsured_idno = {
		validate : function(validator, $field, options) {
			var topvueobj = getTopvueObj(options.vueobj);
			var lcinsured = topvueobj.formdata.lcinsured;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			if(lcinsured.lcinsuredidno.length==18||(lcinsured.lcinsuredidtype!="I"&&lcinsured.lcinsuredidtype!="J")){
				form.data('bootstrapValidator').resetField($("#lcinsuredbirthday"));
				form.data('bootstrapValidator').updateStatus($field, "VALID");
				form.find("input[id*='lcinsuredidno']").each(function() {
					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});
				return true;
			}
			return false;
		}
	};

	bootstrap_valid.lcinsured_idno = function(validitem) {
		
		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};

aftersubmitvueform.lcinsured_tabinfoform = function() {	
	var topvue = getTopvueObj(this);
   console.log("lcinsured_tabinfoform==="+topvue.formdata.newContApply.investment);
	//判断主险是否是六个被保人
   if(topvue.formdata.newContApply.investment=='M'){				
		console.log(vueobj["testdivchange"].formdata.newContApply.insChangeFlag);
		if(vueobj["testdivchange"].formdata.newContApply.insChangeFlag){
			incuredall();
			ClearAll();	
			try {
				if($("#subriskcode_tabinfoform").data('bootstrapValidator')!=null&&
						$("#subriskcode_tabinfoform").data('bootstrapValidator')!=undefined){
						$("#subriskcode_tabinfoform").data('bootstrapValidator').destroy();
				        $('#subriskcode_tabinfoform').data('bootstrapValidator', null);
					}
			} catch (e) {
				// TODO: handle exception
			}
			
		}
	}
   return true;
};
var temp_birthday="";

afterloadNewElements.lcinsured_tabinfo=function(){
	var _this=this;
	var topvue = getTopvueObj(this);
	temp_birthday=topvue.formdata.lcinsured.lcinsuredbirthday;
	 this.$nextTick(function(){		
		    var timer2=setInterval(function(){
			 if($("#lcinsuredname").is(":visible")){
				 $("input[id^='lcinsuredname']").after("<small class='help-block' style='color: blue;'>请核对证件姓名</small>");
			 }
			  clearInterval(timer2);
			   },50);
		});
	 $("input[value='增加新被保人']").click(function(){
		 _this.$nextTick(function(){
			 $(".ti").remove();
			 $("input[id^='lcinsuredname1']").after("<small class='help-block ti' style='color: blue;'>请核对证件姓名</small>");
		 })
	 })
}
//IPS生日 
beforesubmitvueform.lcinsured_tabinfoform=function(){
	var topvue = getTopvueObj(this);
	if(temp_birthday!=""){
		if(topvue.formdata.lcinsured.lcinsuredbirthday!=temp_birthday){
			if(confirm("客户证件生日与建议书系统的录入生日不一致，请点击【确认】保存或【取消】修改证件信息。")){
				return true;
			}else{
				return false;
			}
		}
	}
	return true;
}
